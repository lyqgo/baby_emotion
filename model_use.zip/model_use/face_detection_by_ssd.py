#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/5/8 下午2:51
# @Author  : Bronson
# @Site    : 
# @File    : face_detection_by_ssd.py
# @Software: PyCharm

# 一个比较快的，纯c语言编译的人脸识别项目，本文件中，为包含该库文件    https://github.com/ShiqiYu/libfacedetection


import cv2 as cv
from cv2 import dnn

WIDTH = 300
HEIGHT = 300
root = './model_use'
PROTOTXT = r'F:\Spyder\mobilenetv2_2\model_use\face_detector\deploy.prototxt'
MODEL = r'F:\Spyder\mobilenetv2_2\model_use\face_detector\res10_300x300_ssd_iter_140000.caffemodel'
NET = dnn.readNetFromCaffe(PROTOTXT, MODEL)
# VIDEO = '/home/robin/Documents/landmark/dataset/300VW_Dataset_2015_12_14/538/vid.avi'

def get_facebox(image=None, threshold=0.5):
    """
    Get the bounding box of faces in image.
    """
    rows = image.shape[0]
    cols = image.shape[1]

    confidences = []
    faceboxes = []

    NET.setInput(dnn.blobFromImage(
        image, 1.0, (WIDTH, HEIGHT), (104.0, 177.0, 123.0), False, False))
    detections = NET.forward()

    for result in detections[0, 0, :, :]:
        confidence = result[2]
        if confidence > threshold:
            x_left_bottom = int(result[3] * cols)
            y_left_bottom = int(result[4] * rows)
            x_right_top = int(result[5] * cols)
            y_right_top = int(result[6] * rows)
            confidences.append(confidence)
            faceboxes.append(
                [x_left_bottom, y_left_bottom, x_right_top, y_right_top])
    return confidences, faceboxes


def draw_result(image, confidences, faceboxes):
    """Draw the detection result on image"""
    for result in zip(confidences, faceboxes):
        conf = result[0]
        facebox = result[1]

        cv.rectangle(image, (facebox[0], facebox[1]),
                     (facebox[2], facebox[3]), (0, 255, 0))
        label = "face: %.4f" % conf
        label_size, base_line = cv.getTextSize(
            label, cv.FONT_HERSHEY_SIMPLEX, 0.5, 1)

        cv.rectangle(image, (facebox[0], facebox[1] - label_size[1]),
                     (facebox[0] + label_size[0],
                      facebox[1] + base_line),
                     (0, 255, 0), cv.FILLED)
        cv.putText(image, label, (facebox[0], facebox[1]),
                   cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0))


def draw_box(image, faceboxes, box_color=(0, 0, 255), line_width=4):
    """Draw square boxes on image"""
    for facebox in faceboxes:
        cv.rectangle(image, (facebox[0], facebox[1]),
                     (facebox[2], facebox[3]), box_color, line_width)


def main():
    """The main entrance"""
    cap = cv.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        # frame = cv.imread(r'/Users/xutingxi/Pyprojects/SelfProjects/mystudy/FaceRecognition/a.jpg')
        confidences, faceboxes = get_facebox(frame, threshold=0.5)
        draw_result(frame, confidences, faceboxes)
        # lbp_box = get_lbp_facebox(frame)
        # draw_box(frame, lbp_box)
        cv.imshow("detections", frame)
        if cv.waitKey(100) != -1:
            break


if __name__ == '__main__':
    main()